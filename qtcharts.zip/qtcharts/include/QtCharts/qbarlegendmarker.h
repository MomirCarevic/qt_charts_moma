#include "../../src/charts/legend/qbarlegendmarker.h"
