#include "../../src/charts/qchartview.h"
