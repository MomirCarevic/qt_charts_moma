#include "../../src/charts/barchart/qabstractbarseries.h"
