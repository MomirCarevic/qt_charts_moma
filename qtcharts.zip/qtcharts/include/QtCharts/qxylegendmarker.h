#include "../../src/charts/legend/qxylegendmarker.h"
