#include "../../src/charts/legend/qboxplotlegendmarker.h"
