#include "../../src/charts/piechart/qvpiemodelmapper.h"
