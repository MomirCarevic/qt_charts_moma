#include "../../src/charts/piechart/qpiemodelmapper.h"
