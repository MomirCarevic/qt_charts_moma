#include "../../src/charts/areachart/qareaseries.h"
