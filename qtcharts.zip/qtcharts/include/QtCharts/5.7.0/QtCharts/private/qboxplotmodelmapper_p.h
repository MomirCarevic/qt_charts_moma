#include "../../../../../src/charts/boxplotchart/qboxplotmodelmapper_p.h"
