#include "../../../../../src/charts/chartthememanager_p.h"
