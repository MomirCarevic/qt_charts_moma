#include "../../../../../src/charts/barchart/horizontal/percent/qhorizontalpercentbarseries_p.h"
