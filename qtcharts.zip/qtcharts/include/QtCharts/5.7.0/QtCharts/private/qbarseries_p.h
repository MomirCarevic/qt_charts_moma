#include "../../../../../src/charts/barchart/vertical/bar/qbarseries_p.h"
