#include "../../../../../src/charts/domain/xlogypolardomain_p.h"
