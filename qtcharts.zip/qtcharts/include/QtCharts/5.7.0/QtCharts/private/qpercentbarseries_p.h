#include "../../../../../src/charts/barchart/vertical/percent/qpercentbarseries_p.h"
