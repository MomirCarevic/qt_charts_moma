#include "../../../../../src/charts/barchart/vertical/bar/barchartitem_p.h"
