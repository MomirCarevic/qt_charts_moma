#include "../../../../../src/charts/barchart/vertical/stacked/stackedbarchartitem_p.h"
