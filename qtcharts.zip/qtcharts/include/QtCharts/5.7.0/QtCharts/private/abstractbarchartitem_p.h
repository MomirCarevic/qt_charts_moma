#include "../../../../../src/charts/barchart/abstractbarchartitem_p.h"
