#include "../../../../../src/charts/domain/xlogydomain_p.h"
