#include "../../../../../src/charts/legend/qarealegendmarker_p.h"
