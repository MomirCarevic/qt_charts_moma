#include "../../../../../src/charts/animations/splineanimation_p.h"
