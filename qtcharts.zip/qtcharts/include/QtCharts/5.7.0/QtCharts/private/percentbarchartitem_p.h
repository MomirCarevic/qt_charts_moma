#include "../../../../../src/charts/barchart/vertical/percent/percentbarchartitem_p.h"
