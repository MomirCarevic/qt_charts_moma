#include "../../../../../src/charts/animations/baranimation_p.h"
