#include "../../../../../src/charts/splinechart/qsplineseries_p.h"
