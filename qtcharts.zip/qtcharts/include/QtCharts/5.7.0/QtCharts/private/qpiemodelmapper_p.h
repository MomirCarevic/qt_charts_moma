#include "../../../../../src/charts/piechart/qpiemodelmapper_p.h"
