#include "../../../../../src/charts/barchart/horizontal/stacked/horizontalstackedbarchartitem_p.h"
