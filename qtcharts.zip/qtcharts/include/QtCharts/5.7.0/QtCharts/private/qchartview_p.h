#include "../../../../../src/charts/qchartview_p.h"
