#include "../../../../../src/charts/barchart/horizontal/percent/horizontalpercentbarchartitem_p.h"
