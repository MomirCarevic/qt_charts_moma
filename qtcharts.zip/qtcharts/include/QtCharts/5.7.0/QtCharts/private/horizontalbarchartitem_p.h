#include "../../../../../src/charts/barchart/horizontal/bar/horizontalbarchartitem_p.h"
