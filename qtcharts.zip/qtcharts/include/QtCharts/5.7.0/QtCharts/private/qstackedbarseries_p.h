#include "../../../../../src/charts/barchart/vertical/stacked/qstackedbarseries_p.h"
