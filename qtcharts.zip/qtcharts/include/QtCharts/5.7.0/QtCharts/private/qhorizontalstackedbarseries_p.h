#include "../../../../../src/charts/barchart/horizontal/stacked/qhorizontalstackedbarseries_p.h"
