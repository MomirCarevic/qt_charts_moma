#include "../../../../../src/charts/themes/chartthemedark_p.h"
