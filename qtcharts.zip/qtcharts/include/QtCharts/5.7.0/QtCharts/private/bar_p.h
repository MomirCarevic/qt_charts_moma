#include "../../../../../src/charts/barchart/bar_p.h"
