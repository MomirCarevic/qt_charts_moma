#include "../../../../../src/charts/barchart/qbarmodelmapper_p.h"
