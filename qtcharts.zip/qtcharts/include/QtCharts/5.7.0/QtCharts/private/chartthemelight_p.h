#include "../../../../../src/charts/themes/chartthemelight_p.h"
