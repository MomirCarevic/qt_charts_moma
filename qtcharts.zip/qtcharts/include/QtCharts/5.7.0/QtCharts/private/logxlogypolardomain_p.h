#include "../../../../../src/charts/domain/logxlogypolardomain_p.h"
