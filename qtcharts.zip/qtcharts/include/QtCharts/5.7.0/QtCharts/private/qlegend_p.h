#include "../../../../../src/charts/legend/qlegend_p.h"
