#include "../../../../../src/charts/barchart/qabstractbarseries_p.h"
