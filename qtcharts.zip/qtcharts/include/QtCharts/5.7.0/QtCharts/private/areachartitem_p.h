#include "../../../../../src/charts/areachart/areachartitem_p.h"
