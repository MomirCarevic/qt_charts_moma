#include "../../../../../src/charts/areachart/qareaseries_p.h"
