#include "../../../../../src/charts/themes/chartthemebluecerulean_p.h"
