#include "../../../../../src/charts/legend/qbarlegendmarker_p.h"
