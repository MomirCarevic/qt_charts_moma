#include "../../../../../src/charts/domain/logxypolardomain_p.h"
