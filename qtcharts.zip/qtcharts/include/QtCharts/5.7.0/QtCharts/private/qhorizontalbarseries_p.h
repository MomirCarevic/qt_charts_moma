#include "../../../../../src/charts/barchart/horizontal/bar/qhorizontalbarseries_p.h"
