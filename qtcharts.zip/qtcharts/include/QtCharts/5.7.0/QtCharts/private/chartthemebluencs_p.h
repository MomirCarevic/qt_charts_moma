#include "../../../../../src/charts/themes/chartthemebluencs_p.h"
