#include "../../../../../src/charts/themes/chartthemehighcontrast_p.h"
