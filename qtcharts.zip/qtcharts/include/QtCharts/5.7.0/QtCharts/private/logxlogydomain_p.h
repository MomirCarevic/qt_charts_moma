#include "../../../../../src/charts/domain/logxlogydomain_p.h"
