#include "../../src/charts/splinechart/qsplineseries.h"
