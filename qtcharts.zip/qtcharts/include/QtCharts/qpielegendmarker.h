#include "../../src/charts/legend/qpielegendmarker.h"
