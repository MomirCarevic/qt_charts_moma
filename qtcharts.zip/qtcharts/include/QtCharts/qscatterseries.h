#include "../../src/charts/scatterchart/qscatterseries.h"
