#include "../../src/charts/barchart/vertical/stacked/qstackedbarseries.h"
