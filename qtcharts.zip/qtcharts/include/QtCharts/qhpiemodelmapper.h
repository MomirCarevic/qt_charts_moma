#include "../../src/charts/piechart/qhpiemodelmapper.h"
