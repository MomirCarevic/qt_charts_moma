#include "../../src/charts/barchart/qvbarmodelmapper.h"
