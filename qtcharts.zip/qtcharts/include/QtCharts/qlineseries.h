#include "../../src/charts/linechart/qlineseries.h"
