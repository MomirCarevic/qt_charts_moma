#include "../../src/charts/barchart/vertical/bar/qbarseries.h"
