#include "../../src/charts/barchart/horizontal/stacked/qhorizontalstackedbarseries.h"
