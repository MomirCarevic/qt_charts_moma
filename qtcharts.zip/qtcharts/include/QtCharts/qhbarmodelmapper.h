#include "../../src/charts/barchart/qhbarmodelmapper.h"
