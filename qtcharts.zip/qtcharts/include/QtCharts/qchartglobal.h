#include "../../src/charts/qchartglobal.h"
