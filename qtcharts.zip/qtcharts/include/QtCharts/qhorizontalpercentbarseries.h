#include "../../src/charts/barchart/horizontal/percent/qhorizontalpercentbarseries.h"
