#include "../../src/charts/axis/barcategoryaxis/qbarcategoryaxis.h"
