#include "../../src/charts/boxplotchart/qboxplotmodelmapper.h"
