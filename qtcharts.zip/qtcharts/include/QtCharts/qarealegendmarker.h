#include "../../src/charts/legend/qarealegendmarker.h"
