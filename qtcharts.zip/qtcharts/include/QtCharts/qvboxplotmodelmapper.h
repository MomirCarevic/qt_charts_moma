#include "../../src/charts/boxplotchart/qvboxplotmodelmapper.h"
