#include "../../src/charts/barchart/qbarmodelmapper.h"
