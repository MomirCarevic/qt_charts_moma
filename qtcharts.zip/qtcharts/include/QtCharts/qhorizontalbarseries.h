#include "../../src/charts/barchart/horizontal/bar/qhorizontalbarseries.h"
