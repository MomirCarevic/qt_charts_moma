#include "../../src/charts/piechart/qpieslice.h"
