#include "../../src/charts/legend/qlegend.h"
