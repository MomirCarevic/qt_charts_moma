#include "../../src/charts/xychart/qvxymodelmapper.h"
