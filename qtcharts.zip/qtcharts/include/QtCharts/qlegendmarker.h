#include "../../src/charts/legend/qlegendmarker.h"
